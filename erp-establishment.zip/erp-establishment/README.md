# ERP Établissement — Socle (Tableau de bord + POS)

Ce dépôt contient le **socle fonctionnel** de l'ERP demandé : architecture complète,
base de données modulaire, et deux modules opérationnels codés en entier
(**Tableau de bord** et **POS/Caisse**). Les 16 autres modules listés dans le brief
(Stock, Achats, Fournisseurs, Recettes, Inventaire, Comptabilité, CRM, Fidélité,
Réservations, Événementiel, Piscine, Pâtisserie, Rapports, Administration,
Paramètres, Gestion des tables détaillée, Cuisine/KDS) se branchent sur ce même
socle — le schéma Prisma est déjà pensé pour ça (voir commentaires en bas de
`backend/prisma/schema.prisma`).

## Structure

```
erp-establishment/
├── backend/          Express + Prisma + PostgreSQL (API REST)
├── frontend/          React + TypeScript + Tailwind + Vite (PWA)
└── print-bridge/       Petit serveur local pour imprimer en ESC/POS sur la Xprinter
```

## Démarrage rapide

### 1. Base de données

```bash
cd backend
cp .env.example .env
docker compose up -d          # lance PostgreSQL en local
npm install
npx prisma migrate dev --name init
npm run seed                   # crée un établissement de démo + admin
npm run dev                    # API sur http://localhost:4000
```

Compte de démo créé par le seed : `admin@eventflow.mg` / `admin123`

### 2. Frontend

```bash
cd frontend
npm install
npm run dev                    # http://localhost:5173
```

### 3. Impression thermique (Xprinter ESC/POS)

Le navigateur ne peut pas piloter une imprimante USB directement. Le
`print-bridge` est un petit serveur Node qui tourne sur le PC caisse et fait
le pont :

```bash
cd print-bridge
npm install
npm start                      # écoute sur http://localhost:9100
```

Brancher la Xprinter en USB avant de lancer. Le frontend envoie automatiquement
le ticket à ce bridge lors de l'encaissement (`src/lib/print.ts`).

## Compatibilité plateformes

- **PC Windows** : navigateur (Chrome/Edge) ou packagé en app de bureau via
  Electron (le frontend Vite s'y prête directement).
- **Android / iPhone** : le frontend est configuré comme **PWA**
  (`vite-plugin-pwa`) — "Ajouter à l'écran d'accueil" depuis Safari/Chrome
  donne une app plein écran installable, sans passer par un store.
- **Impression** : voir print-bridge ci-dessus pour Windows/USB. Pour une
  impression directe depuis Android (Bluetooth), il faudra une app native ou
  un wrapper Capacitor avec une librairie ESC/POS Bluetooth — non couvert ici.

## Comptes et rôles

Le modèle `User` a un `role` (`ADMIN`, `MANAGER`, `CASHIER`, `KITCHEN`,
`WAITER`). Le middleware `requireRole()` dans `backend/src/middleware/auth.js`
permet de restreindre chaque route selon le rôle — à utiliser pour verrouiller
les futurs modules sensibles (Comptabilité, Administration, Paramètres).

## Multi-établissement

Chaque enregistrement est rattaché à un `establishmentId`. C'est ce qui permet
à EventFlow (catering événementiel) et au nouvel établissement (piscine,
pâtisserie...) de **partager exactement le même code** tout en gardant leurs
données strictement séparées.

## Prochaines étapes suggérées

1. **Gestion des tables** (vue plan de salle) + **Cuisine/KDS** : le schéma et
   les endpoints (`/pos/tables`, statut `sentAt`/`readyAt` sur `OrderItem`)
   existent déjà côté API — il reste l'écran Kitchen Display en temps réel
   (WebSocket conseillé pour le push instantané).
2. **Stock/Achats/Fournisseurs/Recettes** : modèles à ajouter au schéma
   Prisma, liés à `Product`.
3. **CRM/Fidélité/Réservations/Événementiel/Piscine/Pâtisserie** : modules
   métier spécifiques, chacun avec ses propres écrans mais réutilisant
   `Establishment`, `User`, `Product`.
4. **Comptabilité/Rapports** : peuvent être largement dérivés des tables
   `Order`/`Payment` déjà en place.
5. **Administration/Paramètres** : gestion des utilisateurs, rôles, taxes,
   configuration établissement.

Dis-moi quel module tu veux qu'on code ensuite et on continue module par
module, en gardant cette même base.
